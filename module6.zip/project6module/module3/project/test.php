<html>
<body>
<p>Test</p>
<?php
//Allow Headers
header('Access-Control-Allow-Origin: *');
//$servername = "localhost:3306";
$servername = "localhost:3306";
$username = "thimchandavong";
$password = "Milani3171!!";
$dbname = "adventureworks";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
 if ($conn->connect_error) {
     echo "Error: Unexpected connection error. Please retry the operation.";
}
 else
  {
    echo "successful Connection";`  `
    $sql = "SELECT * FROM address";

     $result = mysqli_query($conn, $sql);
     if (mysqli_num_rows($result) > 0)) {

       while($row = mysqli_fetch_assoc($result)) {
          echo "AdressID: " . $row["AddressLine1"]. " " . $row["AddressLine2"]. " " . $row["City"]. " " . $row["StateProvinceID"]. " " . $row["PostalCode"]. " " . $row["rowguid"]. " " . $row["ModifiedDate"]. ""<br>";
        }
} else {
    echo "0 results"
  }

}
    mysqli_close($conn);
?>
</body>
  </html>
