<html>
<body>
<?php
//Allow Headers
header('Access-Control-Allow-Origin: *');
//$servername = "localhost:3306";
$servername = "localhost:3306";
$username = "thimchandavong";
$password = "Milani3171!!";
$dbname = "thimblelina";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
 if ($conn->connect_error)
     echo "Error: Unexpected connection error. Please retry the operation.";
 else
  {
     $result = $conn->query("SELECT * FROM products");
     if (($result != 0) && ($result->num_rows > 0))
       {
     $Woman = $row['Woman'];
     $Men= $row['Men'];
     $Kid = $row['Kid'];
     $Teen = $row['Teen'];

echo $Woman;
echo $Men;
echo $Kid;
echo $Teen;
       }
     $conn->close();
}
?>
</body>
  </html>
