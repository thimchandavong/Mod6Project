<?php

<div class="container detainfo bg-light">
  <p>

//Allow Headers
header('Access-Control-Allow-Origin: *');
//$servername = "localhost:3306";
$servername = "localhost:3306";
$username = "thimchandavong";
$password = "Milani3171!!";
$dbname = "adventureworks";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
 if ($conn->connect_error)
     echo "Error: Unexpected connection error. Please retry the operation.";
 else
  {
     $result = $conn->query("SELECT * FROM culture");
     if (($result != 0) && ($result->num_rows > 0))
    {
      while (($row = $result->fetch_assoc())
      {


    $CultureID = $row['CultureID'];
    $Name = $row['Name'];
    $ModifiedDate = $row['ModifiedDate'];

    echo '<div class="card result text-left m-2 p-2">';
     echo '<h4 class="text-capitalize">'.$CultureID.'.  '.$Name.'</h4>';
     echo '<p>Type: '.$ModifiedDate.'</p>';

       }
     }
     $conn->close();
  }
?>
</div>
